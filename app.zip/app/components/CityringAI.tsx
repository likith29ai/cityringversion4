"use client";

import { useEffect, useRef, useState } from "react";

type Message = {
  role: "user" | "ai";
  text: string;
};

export default function CityringAI() {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  const [messages, setMessages] = useState<Message[]>([
    {
      role: "ai",
      text: "Hey 👋 Need help finding your people?",
    },
  ]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({
      behavior: "smooth",
    });
  }, [messages, loading]);

  async function sendMessage() {
    if (!input.trim() || loading) return;

    const userMessage = input;

    setMessages((prev) => [
      ...prev,
      {
        role: "user",
        text: userMessage,
      },
    ]);

    setInput("");
    setLoading(true);

    try {
      const res = await fetch("/api/ai", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          message: userMessage,
        }),
      });

      const data = await res.json();

      setMessages((prev) => [
        ...prev,
        {
          role: "ai",
          text:
            data.reply ||
            "Couldn't find anything right now 👀",
        },
      ]);
    } catch {
      setMessages((prev) => [
        ...prev,
        {
          role: "ai",
          text:
            "Something went wrong. Try again.",
        },
      ]);
    }

    setLoading(false);
  }

  return (
    <>
      {/* Floating Button */}
      <button
        onClick={() => setOpen(!open)}
        className="
        fixed
        bottom-24 sm:bottom-6
        right-5 sm:right-6
        z-50

        h-16 w-16
        rounded-full

        bg-gradient-to-br
        from-fuchsia-600
        via-pink-500
        to-rose-500

        text-white text-2xl

        shadow-[0_0_40px_rgba(236,72,153,0.45)]

        hover:scale-110
        active:scale-95

        transition-all duration-300
        "
      >
        ✦
      </button>

      {/* Chat Window */}
      {open && (
        <div
          className="
          fixed z-50

          bottom-20
          left-1/2 -translate-x-1/2

          sm:left-auto
          sm:translate-x-0
          sm:right-6
          sm:bottom-24

          w-[94vw]
          sm:w-[390px]

          h-[82dvh]
          sm:h-[650px]

          max-w-[390px]

          rounded-[30px]

          border border-white/10

          bg-black/45
          backdrop-blur-2xl

          overflow-hidden

          flex flex-col

          shadow-[0_0_80px_rgba(236,72,153,0.18)]

          animate-in fade-in zoom-in-95
          duration-300
          "
        >
          {/* Background Glow */}
          <div
            className="
            absolute inset-0
            bg-gradient-to-br
            from-fuchsia-500/10
            via-transparent
            to-pink-500/10
            pointer-events-none
            "
          />

          {/* Header */}
          <div
            className="
            relative
            px-5 py-4

            border-b border-white/10

            bg-gradient-to-r
            from-fuchsia-500/10
            to-purple-500/5

            backdrop-blur-xl
            "
          >
            <h2
              className="
              text-white
              text-lg
              font-semibold
              tracking-wide
              "
            >
              Cityring AI
            </h2>

            <p
              className="
              text-white/50
              text-sm
              mt-1
              "
            >
              Discover your circle
            </p>
          </div>

          {/* Messages */}
          <div
            className="
            relative
            flex-1
            overflow-y-auto

            px-4 py-5

            space-y-4

            scrollbar-thin
            scrollbar-thumb-white/10
            "
          >
            {messages.map((msg, i) => (
              <div
                key={i}
                className={`w-full flex ${
                  msg.role === "user"
                    ? "justify-end"
                    : "justify-start"
                }`}
              >
                <div
                  className={`
                  max-w-[92%]
                  sm:max-w-[85%]

                  text-[15px]
                  leading-relaxed

                  whitespace-pre-wrap

                  px-4 py-3

                  transition-all duration-300

                  ${
                    msg.role === "user"
                      ? `
                      bg-gradient-to-br
                      from-fuchsia-600
                      via-pink-500
                      to-rose-500

                      text-white

                      rounded-2xl rounded-br-md

                      shadow-[0_0_25px_rgba(236,72,153,0.35)]
                      `
                      : `
                      bg-white/[0.06]

                      border border-white/10

                      backdrop-blur-xl

                      text-white/90

                      rounded-2xl rounded-tl-md

                      shadow-lg
                      `
                  }
                  `}
                >
                  {msg.text}
                </div>
              </div>
            ))}

            {loading && (
              <div
                className="
                w-fit

                bg-white/[0.06]

                border border-white/10

                text-white/60

                px-4 py-3

                rounded-2xl

                animate-pulse
                "
              >
                Thinking...
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div
            className="
            relative

            p-4

            border-t border-white/10

            bg-black/20
            backdrop-blur-xl

            flex items-center gap-2
            "
          >
            <input
              value={input}
              onChange={(e) =>
                setInput(e.target.value)
              }
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  sendMessage();
                }
              }}
              placeholder="Ask about Cityring..."
              className="
              flex-1

              h-12

              bg-white/[0.05]

              border border-white/10

              text-white

              placeholder:text-white/30

              rounded-2xl

              px-4

              outline-none

              focus:border-fuchsia-500/40
              focus:bg-white/[0.08]

              transition-all
              "
            />

            <button
              onClick={sendMessage}
              disabled={loading}
              className="
              h-12

              px-5

              rounded-2xl

              bg-gradient-to-r
              from-fuchsia-600
              via-pink-500
              to-rose-500

              text-white
              font-medium

              shadow-[0_0_20px_rgba(236,72,153,0.35)]

              hover:scale-105
              active:scale-95

              disabled:opacity-50

              transition-all duration-300
              "
            >
              Send
            </button>
          </div>
        </div>
      )}
    </>
  );
}